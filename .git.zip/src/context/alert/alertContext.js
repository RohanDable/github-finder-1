import { createContext } from 'react';

const alertContext = createContext();

export default alertContext;
